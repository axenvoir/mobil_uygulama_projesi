import React, { createContext, useState, useEffect, useRef } from 'react';
import { AppState } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import i18n from '../utils/i18n';

export const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [products, setProducts] = useState([]);
  const [notes, setNotes] = useState([]);
  const [settings, setSettings] = useState({
    dailyReminder: true,
    reminderTime: '09:00',
    instantNotifications: true,
    hapticsEnabled: true,
  });
  const [userProfile, setUserProfile] = useState({
    name: 'Merve',
    avatarColor: '#14B8A6',
    language: 'tr',
    biometricsEnabled: false,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [toast, setToast] = useState(null);
  const [isLocked, setIsLocked] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('Tümü'); 

  const undoStack = useRef(null);
  const undoTimer = useRef(null);
  const appState = useRef(AppState.currentState);
  const backgroundTime = useRef(null);

  useEffect(() => {
    // Sadece ilk açılışta eski barkod verilerini temizle
    const clearOldBarcodeData = async () => {
      try {
        await AsyncStorage.removeItem('@barcodeHistory');
        await AsyncStorage.removeItem('@localBarcodes');
      } catch (e) {}
    };
    clearOldBarcodeData();
    loadData();
  }, []);

  useEffect(() => { if (!isLoading) saveData(); }, [products, notes, settings, userProfile]);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', nextAppState => {
      if (appState.current.match(/inactive|background/) && nextAppState === 'active') {
        if (userProfile.biometricsEnabled) {
          const now = Date.now();
          if (backgroundTime.current && now - backgroundTime.current > 30000) {
            setIsLocked(true);
          }
        }
      } else if (nextAppState.match(/inactive|background/)) {
        backgroundTime.current = Date.now();
      }
      appState.current = nextAppState;
    });
    return () => { subscription.remove(); };
  }, [userProfile.biometricsEnabled]);

  const loadData = async () => {
    try {
      const storedProducts = await AsyncStorage.getItem('@products');
      const storedNotes = await AsyncStorage.getItem('@notes');
      const storedSettings = await AsyncStorage.getItem('@settings');
      const storedProfile = await AsyncStorage.getItem('@userProfile');

      if (storedProducts) setProducts(JSON.parse(storedProducts));
      if (storedNotes) setNotes(JSON.parse(storedNotes));
      if (storedSettings) {
        const parsed = JSON.parse(storedSettings);
        setSettings({ hapticsEnabled: true, ...parsed });
      }
      if (storedProfile) {
        const parsed = JSON.parse(storedProfile);
        setUserProfile({ language: 'tr', biometricsEnabled: false, ...parsed });
        i18n.locale = parsed.language || 'tr';
      }
    } catch (e) {
      // Sessiz hata yönetimi
    } finally {
      setTimeout(() => setIsLoading(false), 1200);
    }
  };

  const saveData = async () => {
    try {
      await AsyncStorage.setItem('@products', JSON.stringify(products));
      await AsyncStorage.setItem('@notes', JSON.stringify(notes));
      await AsyncStorage.setItem('@settings', JSON.stringify(settings));
      await AsyncStorage.setItem('@userProfile', JSON.stringify(userProfile));
    } catch (e) {
      // Sessiz hata yönetimi
    }
  };

  const showToast = (message, type = 'success', duration = 2500, action = null) => {
    setToast({ message, type, id: Date.now(), action });
    if (!action) setTimeout(() => setToast(null), duration);
  };

  const hideToast = () => setToast(null);

  const addProduct = (product) => setProducts([...products, { ...product, id: Date.now().toString() }]);
  
  const deleteProduct = (id, options = {}) => {
    const deleted = products.find(p => p.id === id);
    if (!deleted) return;
    setProducts(products.filter(p => p.id !== id));

    if (options.withUndo && deleted) {
      undoStack.current = { type: 'product', data: deleted };
      if (undoTimer.current) clearTimeout(undoTimer.current);
      
      showToast(`"${deleted.name}" silindi`, 'info', 5000, {
        label: 'Geri Al',
        onPress: () => {
          if (undoStack.current?.type === 'product') {
            setProducts(prev => [...prev, undoStack.current.data]);
            undoStack.current = null;
            showToast('Geri alındı', 'success');
          }
        },
      });
      undoTimer.current = setTimeout(() => { undoStack.current = null; }, 5000);
    }
  };

  const updateProduct = (id, updatedProduct) => {
    setProducts(products.map(p => p.id === id ? { ...updatedProduct, id } : p));
  };

  const addNote = (note) => setNotes([...notes, { ...note, id: Date.now().toString(), pinned: false, color: '#14B8A6' }]);
  
  const deleteNote = (id, options = {}) => {
    const deleted = notes.find(n => n.id === id);
    if (!deleted) return;
    setNotes(notes.filter(n => n.id !== id));

    if (options.withUndo && deleted) {
      undoStack.current = { type: 'note', data: deleted };
      if (undoTimer.current) clearTimeout(undoTimer.current);
      
      showToast(`"${deleted.title}" silindi`, 'info', 5000, {
        label: 'Geri Al',
        onPress: () => {
          if (undoStack.current?.type === 'note') {
            setNotes(prev => [...prev, undoStack.current.data]);
            undoStack.current = null;
            showToast('Geri alındı', 'success');
          }
        },
      });
      undoTimer.current = setTimeout(() => { undoStack.current = null; }, 5000);
    }
  };

  const updateNote = (id, updatedNote) => {
    setNotes(notes.map(n => n.id === id ? { ...n, ...updatedNote, id } : n));
  };
  
  const togglePin = (id) => {
    setNotes(notes.map(n => n.id === id ? { ...n, pinned: !n.pinned } : n));
  };

  const updateSettings = (key, value) => setSettings({ ...settings, [key]: value });
  const updateProfile = (key, value) => setUserProfile(prev => ({ ...prev, [key]: value }));

  const changeLanguage = (lang) => {
    i18n.locale = lang;
    setUserProfile(prev => ({ ...prev, language: lang }));
  };

  const lockApp = () => setIsLocked(true);
  const unlockApp = () => setIsLocked(false);

  return (
    <AppContext.Provider value={{ 
      products, notes, settings, userProfile, isLoading, toast, isLocked,
      selectedCategory, setSelectedCategory,
      addProduct, deleteProduct, updateProduct, 
      addNote, deleteNote, updateNote, togglePin,
      updateSettings, updateProfile, showToast, hideToast,
      changeLanguage, lockApp, unlockApp
    }}>
      {children}
    </AppContext.Provider>
  );
};