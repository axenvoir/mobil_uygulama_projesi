import * as Calendar from 'expo-calendar';
import { Platform, Alert } from 'react-native';

const getCalendarPermissions = async () => {
  const { status } = await Calendar.requestCalendarPermissionsAsync();
  return status === 'granted';
};

const getDefaultCalendarId = async () => {
  try {
    if (Platform.OS === 'ios') {
      const defaultCalendar = await Calendar.getDefaultCalendarAsync();
      return defaultCalendar?.id || null;
    }
    // Android: ilk uygun takvimi bul
    const calendars = await Calendar.getCalendarsAsync(Calendar.EntityTypes.EVENT);
    if (calendars.length === 0) return null;
    // Öncelik: local, sonra google
    const local = calendars.find(c => c.source?.name === 'Local' || c.isLocalAccount);
    return (local || calendars[0]).id;
  } catch (e) {
    console.error('Takvim bulunamadı:', e);
    return null;
  }
};

export const addProductToCalendar = async (product) => {
  try {
    const granted = await getCalendarPermissions();
    if (!granted) {
      return { success: false, error: 'Takvim izni verilmedi.' };
    }

    const calendarId = await getDefaultCalendarId();
    if (!calendarId) {
      return { success: false, error: 'Uygun takvim bulunamadı.' };
    }

    // SKT'den 3 gün önce hatırlatma etkinliği oluştur
    const expDate = new Date(product.expDate);
    const reminderDate = new Date(expDate);
    reminderDate.setDate(reminderDate.getDate() - 3);

    // Eğer hatırlatma tarihi geçmişte kaldıysa, SKT günü etkinlik oluştur
    const targetDate = reminderDate < new Date() ? expDate : reminderDate;

    const startDate = new Date(targetDate);
    startDate.setHours(10, 0, 0, 0);
    const endDate = new Date(targetDate);
    endDate.setHours(11, 0, 0, 0);

    const eventId = await Calendar.createEventAsync(calendarId, {
      title: `⏰ ${product.name} - SKT yaklaşıyor`,
      notes: `${product.name}${product.productCode ? ` [${product.productCode}]` : ''} ürününün son kullanma tarihi: ${product.expDate}`,
      startDate,
      endDate,
      alarms: [{ relativeOffset: 0 }],
    });

    return { success: true, eventId };
  } catch (e) {
    console.error('Takvim etkinliği ekleme hatası:', e);
    return { success: false, error: e.message };
  }
};