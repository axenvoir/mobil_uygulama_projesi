import React, { useState, useEffect, useContext } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppContext } from '../context/AppContext';
import { COLORS } from '../theme';
import { createBackup, restoreBackup, getBackupSummary, resetAllData } from '../utils/backupUtils';
import { notifySuccess, notifyError } from '../utils/haptics';

export default function BackupScreen({ navigation }) {
  const { showToast, settings } = useContext(AppContext);
  const [summary, setSummary] = useState({ products: 0, notes: 0 });
  const [loading, setLoading] = useState(false);

  useEffect(() => { loadSummary(); }, []);

  const loadSummary = async () => {
    const s = await getBackupSummary();
    setSummary(s);
  };

  const handleBackup = async () => {
    setLoading(true);
    if (settings.hapticsEnabled) await notifySuccess();
    const result = await createBackup();
    setLoading(false);
    if (result.success) showToast('Yedek oluşturuldu!', 'success');
    else {
      if (settings.hapticsEnabled) await notifyError();
      showToast('Yedek oluşturulamadı: ' + result.error, 'error');
    }
  };

  const handleRestore = () => {
    Alert.alert('Yedekten Yükle', 'Mevcut veriler yedektekilerle DEĞİŞTİRİLECEK. Devam?', [
      { text: 'İptal', style: 'cancel' },
      {
        text: 'Devam Et',
        onPress: async () => {
          setLoading(true);
          const result = await restoreBackup();
          setLoading(false);
          if (result.canceled) { showToast('İptal edildi.', 'info'); return; }
          if (result.success) {
            if (settings.hapticsEnabled) await notifySuccess();
            Alert.alert('Yedek Yüklendi!', `${result.stats.products} ürün ve ${result.stats.notes} not geri yüklendi.\n\nUygulamayı yeniden başlatmanız önerilir.`);
            await loadSummary();
          } else {
            if (settings.hapticsEnabled) await notifyError();
            showToast('Yedek yüklenemedi: ' + result.error, 'error');
          }
        },
      },
    ]);
  };

  const handleReset = () => {
    Alert.alert('⚠️ Tüm Verileri Sil', 'TÜM veriler silinecek. Geri alınamaz!', [
      { text: 'İptal', style: 'cancel' },
      {
        text: 'Evet, Sil', style: 'destructive',
        onPress: () => {
          Alert.alert('Son Uyarı', 'Gerçekten silmek istiyor musun?', [
            { text: 'Vazgeç', style: 'cancel' },
            {
              text: 'SİL', style: 'destructive',
              onPress: async () => {
                const result = await resetAllData();
                if (result.success) { showToast('Veriler silindi.', 'info'); await loadSummary(); }
                else showToast('Silinemedi.', 'error');
              },
            },
          ]);
        },
      },
    ]);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={COLORS.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Yedekleme</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.summaryCard}>
        <Ionicons name="archive-outline" size={40} color={COLORS.primary} />
        <Text style={styles.summaryTitle}>Mevcut Veriler</Text>
        <View style={styles.summaryGrid}>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryNumber}>{summary.products}</Text>
            <Text style={styles.summaryLabel}>Ürün</Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryNumber}>{summary.notes}</Text>
            <Text style={styles.summaryLabel}>Not</Text>
          </View>
        </View>
      </View>

      <Text style={styles.sectionTitle}>İşlemler</Text>

      <TouchableOpacity style={styles.actionCard} onPress={handleBackup} disabled={loading}>
        <View style={[styles.actionIcon, { backgroundColor: '#E6F4F1' }]}>
          <Ionicons name="cloud-upload-outline" size={24} color={COLORS.primary} />
        </View>
        <View style={{ flex: 1, marginLeft: 14 }}>
          <Text style={styles.actionTitle}>Yedek Oluştur</Text>
          <Text style={styles.actionDesc}>Tüm verilerini JSON olarak paylaş</Text>
        </View>
        <Ionicons name="chevron-forward" size={20} color={COLORS.textLight} />
      </TouchableOpacity>

      <TouchableOpacity style={styles.actionCard} onPress={handleRestore} disabled={loading}>
        <View style={[styles.actionIcon, { backgroundColor: '#EFF6FF' }]}>
          <Ionicons name="cloud-download-outline" size={24} color="#3B82F6" />
        </View>
        <View style={{ flex: 1, marginLeft: 14 }}>
          <Text style={styles.actionTitle}>Yedekten Yükle</Text>
          <Text style={styles.actionDesc}>Daha önce oluşturduğun yedeği geri yükle</Text>
        </View>
        <Ionicons name="chevron-forward" size={20} color={COLORS.textLight} />
      </TouchableOpacity>

      <Text style={[styles.sectionTitle, { color: COLORS.danger, marginTop: 24 }]}>Tehlikeli Bölge</Text>

      <TouchableOpacity style={[styles.actionCard, { borderColor: '#FEE2E2', borderWidth: 1 }]} onPress={handleReset}>
        <View style={[styles.actionIcon, { backgroundColor: '#FEE2E2' }]}>
          <Ionicons name="trash-outline" size={24} color={COLORS.danger} />
        </View>
        <View style={{ flex: 1, marginLeft: 14 }}>
          <Text style={[styles.actionTitle, { color: COLORS.danger }]}>Tüm Verileri Sil</Text>
          <Text style={styles.actionDesc}>Tüm verileri sıfırla (geri alınamaz)</Text>
        </View>
        <Ionicons name="chevron-forward" size={20} color={COLORS.danger} />
      </TouchableOpacity>

      <View style={styles.infoBox}>
        <Ionicons name="information-circle-outline" size={20} color={COLORS.primary} />
        <Text style={styles.infoText}>Yedek dosyan tüm verilerini içerir. Güvenli bir yerde sakla.</Text>
      </View>

      {loading && (
        <View style={styles.loadingOverlay}>
          <View style={styles.loadingBox}>
            <ActivityIndicator size="large" color={COLORS.primary} />
            <Text style={styles.loadingText}>İşlem yapılıyor...</Text>
          </View>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background, padding: 20, paddingBottom: 100 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 },
  headerTitle: { fontSize: 22, fontWeight: 'bold', color: COLORS.primaryDark },
  summaryCard: { backgroundColor: COLORS.white, borderRadius: 16, padding: 20, alignItems: 'center', marginBottom: 24, elevation: 3 },
  summaryTitle: { fontSize: 16, fontWeight: 'bold', color: COLORS.text, marginTop: 10, marginBottom: 16 },
  summaryGrid: { flexDirection: 'row', justifyContent: 'space-around', width: '100%' },
  summaryItem: { alignItems: 'center', paddingVertical: 12 },
  summaryNumber: { fontSize: 30, fontWeight: 'bold', color: COLORS.primary },
  summaryLabel: { fontSize: 12, color: COLORS.textLight, marginTop: 4 },
  sectionTitle: { fontSize: 15, fontWeight: 'bold', color: COLORS.text, marginBottom: 12 },
  actionCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.white, padding: 16, borderRadius: 12, marginBottom: 10, elevation: 2 },
  actionIcon: { width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center' },
  actionTitle: { fontSize: 15, fontWeight: 'bold', color: COLORS.text },
  actionDesc: { fontSize: 12, color: COLORS.textLight, marginTop: 2, lineHeight: 17 },
  infoBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#E6F4F1', padding: 14, borderRadius: 12, marginTop: 20 },
  infoText: { flex: 1, fontSize: 12, color: COLORS.textLight, marginLeft: 8, lineHeight: 18 },
  loadingOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  loadingBox: { backgroundColor: COLORS.white, padding: 24, borderRadius: 16, alignItems: 'center' },
  loadingText: { fontSize: 13, color: COLORS.text, marginTop: 12, fontWeight: '600' },
});