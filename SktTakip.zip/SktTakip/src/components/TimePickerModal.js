import React, { useState, useEffect, useMemo } from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../hooks/useTheme';
import { useResponsive } from '../hooks/useResponsive';
import { TYPOGRAPHY } from '../theme';

export default function TimePickerModal({ visible, onClose, onSelect, initialTime }) {
  const { colors } = useTheme();
  const responsive = useResponsive();
  const { isTablet, scale, moderateScale } = responsive;
  const styles = useMemo(() => createStyles(colors, responsive), [colors, isTablet]);

  const parseInitial = () => {
    if (initialTime && initialTime.includes(':')) {
      const [h, m] = initialTime.split(':').map(n => parseInt(n));
      return { hour: h, minute: m };
    }
    return { hour: 9, minute: 0 };
  };

  const [hour, setHour] = useState(9);
  const [minute, setMinute] = useState(0);

  useEffect(() => {
    if (visible) {
      const t = parseInitial();
      setHour(t.hour);
      setMinute(t.minute);
    }
  }, [visible]);

  const hours = Array.from({ length: 24 }, (_, i) => i);
  const minutes = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55];

  const handleConfirm = () => {
    onSelect(`${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`);
    onClose();
  };

  const presets = [
    { label: 'Sabah 08:00', h: 8, m: 0 },
    { label: 'Öğle 12:00', h: 12, m: 0 },
    { label: 'Akşam 18:00', h: 18, m: 0 },
    { label: 'Gece 21:00', h: 21, m: 0 },
  ];

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={[styles.overlay, { backgroundColor: 'rgba(0,0,0,0.7)' }]}>
        <View style={styles.container}>
          <View style={styles.header}>
            <Text style={styles.title}>Bildirim Zamanı</Text>
            <TouchableOpacity onPress={onClose} activeOpacity={0.7}>
              <Ionicons name="close" size={scale(24)} color={colors.text} />
            </TouchableOpacity>
          </View>

          <View style={styles.presetsRow}>
            {presets.map((p) => (
              <TouchableOpacity key={p.label} style={[styles.presetBtn, hour === p.h && minute === p.m && styles.presetBtnActive]} onPress={() => { setHour(p.h); setMinute(p.m); }} activeOpacity={0.7}>
                <Text style={[styles.presetText, hour === p.h && minute === p.m && styles.presetTextActive]}>{p.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.previewBox}>
            <Text style={styles.previewTime}>{String(hour).padStart(2, '0')}:{String(minute).padStart(2, '0')}</Text>
            <Text style={styles.previewLabel}>seçilen saat</Text>
          </View>

          <Text style={styles.pickerLabel}>Saat</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.pickerScroll}>
            {hours.map((h) => (
              <TouchableOpacity key={h} style={[styles.timeChip, hour === h && styles.timeChipActive]} onPress={() => setHour(h)} activeOpacity={0.7}>
                <Text style={[styles.timeChipText, hour === h && styles.timeChipTextActive]}>{String(h).padStart(2, '0')}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <Text style={styles.pickerLabel}>Dakika</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.pickerScroll}>
            {minutes.map((m) => (
              <TouchableOpacity key={m} style={[styles.timeChip, minute === m && styles.timeChipActive]} onPress={() => setMinute(m)} activeOpacity={0.7}>
                <Text style={[styles.timeChipText, minute === m && styles.timeChipTextActive]}>{String(m).padStart(2, '0')}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <View style={styles.btnRow}>
            <TouchableOpacity style={styles.cancelBtn} onPress={onClose} activeOpacity={0.7}>
              <Text style={styles.cancelBtnText}>İptal</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.confirmBtn} onPress={handleConfirm} activeOpacity={0.8}>
              <Ionicons name="checkmark" size={scale(20)} color={colors.white} />
              <Text style={styles.confirmBtnText}>Onayla</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const createStyles = (colors, responsive) => {
  const { isTablet, scale, moderateScale } = responsive;
  return StyleSheet.create({
    overlay: { flex: 1, justifyContent: 'flex-end' },
    container: { backgroundColor: colors.surface, borderTopLeftRadius: scale(24), borderTopRightRadius: scale(24), padding: scale(20), maxHeight: '85%' },
    header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: scale(16) },
    title: { fontSize: moderateScale(TYPOGRAPHY.h3, 0.3), fontWeight: '800', color: colors.text },
    presetsRow: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: scale(16) },
    presetBtn: { paddingHorizontal: scale(10), paddingVertical: scale(6), borderRadius: scale(14), backgroundColor: colors.surfaceAlt, marginRight: scale(6), marginBottom: scale(6) },
    presetBtnActive: { backgroundColor: colors.primary },
    presetText: { fontSize: moderateScale(TYPOGRAPHY.small, 0.3), fontWeight: '600', color: colors.textLight },
    presetTextActive: { color: colors.white },
    previewBox: { alignItems: 'center', backgroundColor: colors.primary + '15', paddingVertical: scale(16), borderRadius: scale(16), marginBottom: scale(16) },
    previewTime: { fontSize: scale(44), fontWeight: 'bold', color: colors.primary },
    previewLabel: { fontSize: moderateScale(TYPOGRAPHY.small, 0.3), color: colors.textLight, fontWeight: '600', marginTop: scale(2) },
    pickerLabel: { fontSize: moderateScale(TYPOGRAPHY.caption, 0.3), fontWeight: 'bold', color: colors.text, marginBottom: scale(8) },
    pickerScroll: { maxHeight: scale(50), marginBottom: scale(12) },
    timeChip: { width: scale(48), height: scale(44), borderRadius: scale(12), backgroundColor: colors.surfaceAlt, justifyContent: 'center', alignItems: 'center', marginRight: scale(8) },
    timeChipActive: { backgroundColor: colors.primary },
    timeChipText: { fontSize: moderateScale(TYPOGRAPHY.body, 0.3), fontWeight: 'bold', color: colors.textLight },
    timeChipTextActive: { color: colors.white },
    btnRow: { flexDirection: 'row', marginTop: scale(8) },
    cancelBtn: { flex: 1, height: scale(50), borderRadius: scale(25), justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: colors.border, marginRight: scale(6) },
    cancelBtnText: { color: colors.text, fontSize: moderateScale(TYPOGRAPHY.body, 0.3), fontWeight: '600' },
    confirmBtn: { flex: 1, height: scale(50), borderRadius: scale(25), justifyContent: 'center', alignItems: 'center', backgroundColor: colors.primary, marginLeft: scale(6), flexDirection: 'row' },
    confirmBtnText: { color: colors.white, fontSize: moderateScale(TYPOGRAPHY.body, 0.3), fontWeight: 'bold', marginLeft: scale(6) },
  });
};