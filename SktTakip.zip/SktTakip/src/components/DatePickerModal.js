import React, { useState, useEffect, useMemo } from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../hooks/useTheme';
import { useResponsive } from '../hooks/useResponsive';
import { TYPOGRAPHY } from '../theme';

const MONTHS = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
const DAYS = ['Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct', 'Pz'];

export default function DatePickerModal({ visible, onClose, onSelect, initialDate }) {
  const { colors } = useTheme();
  const responsive = useResponsive();
  const { isTablet, scale, moderateScale } = responsive;
  const styles = useMemo(() => createStyles(colors, responsive), [colors, isTablet]);

  const parseInitial = () => {
    if (initialDate) {
      const parts = initialDate.split('-');
      if (parts.length === 3) return new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
    }
    return new Date();
  };

  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());

  useEffect(() => {
    if (visible) {
      const d = parseInitial();
      setSelectedDate(d);
      setCurrentDate(d);
    }
  }, [visible]);

  const getDaysInMonth = (year, month) => new Date(year, month + 1, 0).getDate();
  const getFirstDayOfMonth = (year, month) => {
    const day = new Date(year, month, 1).getDay();
    return day === 0 ? 6 : day - 1;
  };

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDayOfMonth(year, month);

  const today = new Date();
  const isToday = (day) => today.getDate() === day && today.getMonth() === month && today.getFullYear() === year;
  const isSelected = (day) => selectedDate.getDate() === day && selectedDate.getMonth() === month && selectedDate.getFullYear() === year;

  const goToPrevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const goToNextMonth = () => setCurrentDate(new Date(year, month + 1, 1));
  const handleDayPress = (day) => setSelectedDate(new Date(year, month, day));

  const handleConfirm = () => {
    const y = selectedDate.getFullYear();
    const m = String(selectedDate.getMonth() + 1).padStart(2, '0');
    const d = String(selectedDate.getDate()).padStart(2, '0');
    onSelect(`${y}-${m}-${d}`);
    onClose();
  };

  const setQuickDate = (daysToAdd) => {
    const d = new Date();
    d.setDate(d.getDate() + daysToAdd);
    setSelectedDate(d);
    setCurrentDate(d);
  };

  const grid = [];
  for (let i = 0; i < firstDay; i++) grid.push(null);
  for (let i = 1; i <= daysInMonth; i++) grid.push(i);

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={[styles.overlay, { backgroundColor: 'rgba(0,0,0,0.7)' }]}>
        <View style={styles.container}>
          <View style={styles.header}>
            <Text style={styles.title}>Tarih Seç</Text>
            <TouchableOpacity onPress={onClose} activeOpacity={0.7}>
              <Ionicons name="close" size={scale(24)} color={colors.text} />
            </TouchableOpacity>
          </View>

          <View style={styles.quickRow}>
            {[{ label: 'Bugün', days: 0 }, { label: '1 Hafta', days: 7 }, { label: '1 Ay', days: 30 }, { label: '6 Ay', days: 180 }, { label: '1 Yıl', days: 365 }].map((q) => (
              <TouchableOpacity key={q.label} style={styles.quickBtn} onPress={() => setQuickDate(q.days)} activeOpacity={0.7}>
                <Text style={styles.quickText}>{q.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.monthNav}>
            <TouchableOpacity onPress={goToPrevMonth} style={styles.navBtn} activeOpacity={0.7}>
              <Ionicons name="chevron-back" size={scale(22)} color={colors.primary} />
            </TouchableOpacity>
            <Text style={styles.monthText}>{MONTHS[month]} {year}</Text>
            <TouchableOpacity onPress={goToNextMonth} style={styles.navBtn} activeOpacity={0.7}>
              <Ionicons name="chevron-forward" size={scale(22)} color={colors.primary} />
            </TouchableOpacity>
          </View>

          <View style={styles.weekRow}>
            {DAYS.map((d, i) => (
              <Text key={i} style={styles.weekDay}>{d}</Text>
            ))}
          </View>

          <View style={styles.grid}>
            {grid.map((day, i) => (
              <TouchableOpacity
                key={i}
                style={[styles.dayCell, day && isSelected(day) && styles.dayCellSelected, day && isToday(day) && !isSelected(day) && styles.dayCellToday]}
                disabled={!day}
                onPress={() => handleDayPress(day)}
                activeOpacity={0.7}
              >
                {day && <Text style={[styles.dayText, isSelected(day) && styles.dayTextSelected, isToday(day) && !isSelected(day) && styles.dayTextToday]}>{day}</Text>}
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.selectedInfo}>
            <Ionicons name="calendar" size={scale(18)} color={colors.primary} />
            <Text style={styles.selectedText}>
              {selectedDate.getDate()} {MONTHS[selectedDate.getMonth()]} {selectedDate.getFullYear()}
            </Text>
          </View>

          <View style={styles.btnRow}>
            <TouchableOpacity style={styles.cancelBtn} onPress={onClose} activeOpacity={0.7}>
              <Text style={styles.cancelBtnText}>İptal</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.confirmBtn} onPress={handleConfirm} activeOpacity={0.8}>
              <Text style={styles.confirmBtnText}>Onayla</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const createStyles = (colors, responsive) => {
  const { isTablet, scale, moderateScale } = responsive;
  return StyleSheet.create({
    overlay: { flex: 1, justifyContent: 'flex-end' },
    container: { backgroundColor: colors.surface, borderTopLeftRadius: scale(24), borderTopRightRadius: scale(24), padding: scale(20), maxHeight: '90%' },
    header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: scale(16) },
    title: { fontSize: moderateScale(TYPOGRAPHY.h3, 0.3), fontWeight: '800', color: colors.text },
    quickRow: { flexDirection: 'row', marginBottom: scale(16), flexWrap: 'wrap' },
    quickBtn: { paddingHorizontal: scale(12), paddingVertical: scale(6), backgroundColor: colors.primary + '15', borderRadius: scale(16), marginRight: scale(6), marginBottom: scale(6) },
    quickText: { color: colors.primary, fontSize: moderateScale(TYPOGRAPHY.small, 0.3), fontWeight: '600' },
    monthNav: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: scale(12) },
    navBtn: { padding: scale(8), backgroundColor: colors.primary + '15', borderRadius: scale(50) },
    monthText: { fontSize: moderateScale(TYPOGRAPHY.body, 0.3), fontWeight: '800', color: colors.text },
    weekRow: { flexDirection: 'row', marginBottom: scale(8) },
    weekDay: { flex: 1, textAlign: 'center', fontSize: moderateScale(TYPOGRAPHY.small, 0.3), fontWeight: 'bold', color: colors.textLight },
    grid: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: scale(16) },
    dayCell: { width: '14.28%', height: scale(42), justifyContent: 'center', alignItems: 'center' },
    dayCellSelected: { backgroundColor: colors.primary, borderRadius: scale(21) },
    dayCellToday: { borderWidth: 1.5, borderColor: colors.primary, borderRadius: scale(21) },
    dayText: { fontSize: moderateScale(TYPOGRAPHY.caption, 0.3), color: colors.text },
    dayTextSelected: { color: colors.white, fontWeight: 'bold' },
    dayTextToday: { color: colors.primary, fontWeight: 'bold' },
    selectedInfo: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: colors.primary + '15', padding: scale(12), borderRadius: scale(12), marginBottom: scale(16) },
    selectedText: { marginLeft: scale(8), fontSize: moderateScale(TYPOGRAPHY.caption, 0.3), fontWeight: 'bold', color: colors.text },
    btnRow: { flexDirection: 'row' },
    cancelBtn: { flex: 1, height: scale(50), borderRadius: scale(25), justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: colors.border, marginRight: scale(6) },
    cancelBtnText: { color: colors.text, fontSize: moderateScale(TYPOGRAPHY.body, 0.3), fontWeight: '600' },
    confirmBtn: { flex: 1, height: scale(50), borderRadius: scale(25), justifyContent: 'center', alignItems: 'center', backgroundColor: colors.primary, marginLeft: scale(6) },
    confirmBtnText: { color: colors.white, fontSize: moderateScale(TYPOGRAPHY.body, 0.3), fontWeight: 'bold' },
  });
};