import React from 'react';
import { View, TouchableOpacity, StyleSheet, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context'; // YENİ EKLENDİ
import { useTheme } from '../hooks/useTheme';
import { useResponsive } from '../hooks/useResponsive';
import { SHADOWS } from '../theme';

export default function CustomTabBar({ state, descriptors, navigation }) {
  const { colors } = useTheme();
  const responsive = useResponsive();
  const { isTablet, scale, icon, fontSize } = responsive;
  const insets = useSafeAreaInsets(); // Çentik/Gesture bar yüksekliği
  
  const height = scale(isTablet ? 85 : 75);
  const iconSize = icon(isTablet ? 26 : 23);
  const plusSize = scale(isTablet ? 70 : 60);
  
  // Alt menünün toplam yüksekliği = Kendi boyu + Telefonun alt çentiği
  const totalHeight = height + insets.bottom;

  return (
    <View style={[styles.outerContainer, { backgroundColor: colors.tabBar, height: totalHeight, paddingBottom: insets.bottom }, SHADOWS.heavy]}>
      <View style={styles.tabContainer}>
        {state.routes.map((route, index) => {
          const isFocused = state.index === index;

          if (route.name === 'AddProduct') {
            return (
              <TouchableOpacity
                key={index}
                activeOpacity={0.8}
                style={[styles.plusButton, {
                  width: plusSize, height: plusSize, borderRadius: plusSize / 2,
                  backgroundColor: colors.primary,
                  borderColor: colors.background,
                  marginTop: -plusSize / 2,
                }, SHADOWS.medium]}
                onPress={() => navigation.navigate('AddProduct')}
              >
                <Ionicons name="add" size={icon(isTablet ? 38 : 32)} color={colors.white} />
              </TouchableOpacity>
            );
          }

          const onPress = () => { if (!isFocused) navigation.navigate(route.name); };

          let iconName;
          let label;
          if (route.name === 'Home') { iconName = isFocused ? 'home' : 'home-outline'; label = 'Ana Sayfa'; }
          else if (route.name === 'Products') { iconName = isFocused ? 'cube' : 'cube-outline'; label = 'Ürünler'; }
          else if (route.name === 'Notes') { iconName = isFocused ? 'document-text' : 'document-text-outline'; label = 'Notlar'; }
          else if (route.name === 'Notifications') { iconName = isFocused ? 'notifications' : 'notifications-outline'; label = 'Bildirim'; }

          return (
            <TouchableOpacity key={index} onPress={onPress} activeOpacity={0.7} style={styles.tabItem}>
              <View style={styles.iconWrapper}>
                <Ionicons
                  name={iconName}
                  size={iconSize}
                  color={isFocused ? colors.tabBarActive : colors.tabBarInactive}
                />
                {isFocused && (
                  <View style={[styles.activeDot, { backgroundColor: colors.tabBarActive, width: scale(5), height: scale(5), borderRadius: scale(2.5), bottom: -scale(8) }]} />
                )}
              </View>
              <Text
                numberOfLines={1}
                adjustsFontSizeToFit
                style={[styles.tabLabel, {
                  color: isFocused ? colors.tabBarActive : colors.tabBarInactive,
                  fontSize: fontSize(isTablet ? 11 : 9.5),
                  fontWeight: isFocused ? '800' : '600',
                  marginTop: scale(4)
                }]}
              >
                {label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  outerContainer: { 
    width: '100%', 
    position: 'absolute', // İçeriğin üzerine binmesi için
    bottom: 0, // En alta sabitle
    zIndex: 1000, // Her zaman en üstte kalması için
    borderTopLeftRadius: 24, 
    borderTopRightRadius: 24, 
    // overflow: 'hidden' KALDIRILDI (Butonun taşması için)
  },
  tabContainer: { 
    flexDirection: 'row', 
    flex: 1,
    alignItems: 'center',
    justifyContent: 'space-around',
  },
  tabItem: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  iconWrapper: { alignItems: 'center', justifyContent: 'center' },
  activeDot: { position: 'absolute' },
  tabLabel: { textAlign: 'center', width: '100%', letterSpacing: 0.2 },
  plusButton: { 
    justifyContent: 'center', 
    alignItems: 'center', 
    borderWidth: 5, 
    zIndex: 2000, // Butonu en üst katmana çıkar
  },
});