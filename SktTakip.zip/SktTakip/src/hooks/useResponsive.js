import { useWindowDimensions } from 'react-native';

const BASE_WIDTH = 375;
const BASE_HEIGHT = 812;

export const useResponsive = () => {
  const { width, height } = useWindowDimensions();

  const isSmall = width < 360;
  const isMedium = width >= 360 && width < 414;
  const isLarge = width >= 414;
  const isTablet = width >= 768;
  const isLandscape = width > height;

  const scale = (size) => (width / BASE_WIDTH) * size;
  const verticalScale = (size) => (height / BASE_HEIGHT) * size;
  
  // Faktör 0.5'e çıkarıldı (Daha az agresif küçülme)
  const moderateScale = (size, factor = 0.5) => size + (scale(size) - size) * factor;

  // Fontlar için minimum 12px sınırı konuldu
  const fontSize = (base) => Math.max(12, Math.round(moderateScale(base, 0.4)));
  
  // İkonlar için minimum 18px sınırı konuldu
  const icon = (base) => Math.max(18, Math.round(moderateScale(base, 0.4)));
  
  const spacing = (base) => Math.round(moderateScale(base, 0.5));

  return {
    width,
    height,
    isSmall,
    isMedium,
    isLarge,
    isTablet,
    isLandscape,
    scale,
    verticalScale,
    moderateScale,
    fontSize,
    icon,
    spacing,
    horizontalPadding: isTablet ? scale(32) : isSmall ? scale(16) : scale(22),
    contentMaxWidth: isTablet ? 700 : width,
    itemColumns: isTablet ? 2 : 1,
    itemGap: isTablet ? scale(16) : scale(10),
    cardPadding: isTablet ? scale(20) : scale(16),
    sectionSpacing: isTablet ? scale(32) : scale(20),
  };
};