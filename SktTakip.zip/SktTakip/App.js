import 'react-native-gesture-handler';
import React, { useContext, useEffect } from 'react';
import { View, StyleSheet, StatusBar } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { AppProvider, AppContext } from './src/context/AppContext';
import { ThemeProvider } from './src/context/ThemeContext';
import CustomTabBar from './src/components/CustomTabBar';
import Toast from './src/components/Toast';
import LoadingScreen from './src/components/LoadingScreen';
import ErrorBoundary from './src/components/ErrorBoundary';
import BiometricLockScreen from './src/screens/BiometricLockScreen';
import { useTheme } from './src/hooks/useTheme';

import HomeScreen from './src/screens/HomeScreen';
import ProductsScreen from './src/screens/ProductsScreen';
import ProductDetailScreen from './src/screens/ProductDetailScreen';
import AddProductScreen from './src/screens/AddProductScreen';
import EditProductScreen from './src/screens/EditProductScreen';
import NotesScreen from './src/screens/NotesScreen';
import AddNoteScreen from './src/screens/AddNoteScreen';
import NotificationsScreen from './src/screens/NotificationsScreen';
import StatisticsScreen from './src/screens/StatisticsScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import CategoriesScreen from './src/screens/CategoriesScreen';
import HelpScreen from './src/screens/HelpScreen';
import BackupScreen from './src/screens/BackupScreen';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

function MainTabs() {
  return (
    <Tab.Navigator tabBar={(props) => <CustomTabBar {...props} />} screenOptions={{ headerShown: false }}>
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Products" component={ProductsScreen} />
      <Tab.Screen name="AddProduct" component={AddProductScreen} />
      <Tab.Screen name="Notes" component={NotesScreen} />
      <Tab.Screen name="Notifications" component={NotificationsScreen} />
    </Tab.Navigator>
  );
}

function AppContent() {
  const { isLoading, toast, userProfile, isLocked, lockApp, hideToast } = useContext(AppContext);
  const { colors, isDark } = useTheme();

  useEffect(() => {
    if (!isLoading && userProfile.biometricsEnabled) {
      lockApp();
    }
  }, [isLoading, userProfile.biometricsEnabled]);

  if (isLoading) return <LoadingScreen />;
  if (isLocked) return <BiometricLockScreen />;

  return (
    <View style={styles.root}>
      <StatusBar 
        barStyle={isDark ? 'light-content' : 'dark-content'} 
        backgroundColor={colors.background} 
        translucent={false}
      />
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          <Stack.Screen name="MainTabs" component={MainTabs} />
          <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
          <Stack.Screen name="EditProduct" component={EditProductScreen} />
          <Stack.Screen name="AddNote" component={AddNoteScreen} />
          <Stack.Screen name="Statistics" component={StatisticsScreen} />
          <Stack.Screen name="Profile" component={ProfileScreen} />
          <Stack.Screen name="Categories" component={CategoriesScreen} />
          <Stack.Screen name="Help" component={HelpScreen} />
          <Stack.Screen name="Backup" component={BackupScreen} />
        </Stack.Navigator>
      </NavigationContainer>
      <Toast toast={toast} onHide={hideToast} />
    </View>
  );
}

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <ErrorBoundary>
        <ThemeProvider>
          <AppProvider>
            <AppContent />
          </AppProvider>
        </ThemeProvider>
      </ErrorBoundary>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
});